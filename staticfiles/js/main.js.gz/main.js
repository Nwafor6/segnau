const button = document.querySelector('button');
button.addEventListener('click', () =>{
    document.querySelector("#success-msg").style.display="none"
}
    )

let _show1= document.querySelector(".show1");
_show1.addEventListener('click',()=>{
    document.querySelector(".showmore1").style.display="inline"
    document.querySelector(".show1").style.display="none"
    document.querySelector(".close1").style.display="inline"
}

    )
let _close1= document.querySelector(".close1");
_close1.addEventListener('click',()=>{
    document.querySelector(".showmore1").style.display="none"
    document.querySelector(".show1").style.display="inline"
    document.querySelector(".close1").style.display="none"
}

    )
let _show2= document.querySelector(".show2");
_show2.addEventListener('click',()=>{
    document.querySelector(".showmore2").style.display="inline"
    document.querySelector(".show2").style.display="none"
    document.querySelector(".close2").style.display="inline"
}

    )
let _close2= document.querySelector(".close2");
_close2.addEventListener('click',()=>{
    document.querySelector(".showmore2").style.display="none"
    document.querySelector(".show2").style.display="inline"
    document.querySelector(".close2").style.display="none"
}

    )
let _show3= document.querySelector(".show3");
_show3.addEventListener('click',()=>{
    document.querySelector(".showmore3").style.display="inline"
    document.querySelector(".show3").style.display="none"
    document.querySelector(".close3").style.display="inline"
}

    )
let _close3= document.querySelector(".close3");
_close3.addEventListener('click',()=>{
    document.querySelector(".showmore3").style.display="none"
    document.querySelector(".show3").style.display="inline"
    document.querySelector(".close3").style.display="none"
}

    )

let _show4= document.querySelector(".show4");
_show4.addEventListener('click',()=>{
    document.querySelector(".showmore4").style.display="inline"
    document.querySelector(".show4").style.display="none"
    document.querySelector(".close4").style.display="inline"
}

    )
let _close4= document.querySelector(".close4");
_close4.addEventListener('click',()=>{
    document.querySelector(".showmore4").style.display="none"
    document.querySelector(".show4").style.display="inline"
    document.querySelector(".close4").style.display="none"
}

    )

let _show5= document.querySelector(".show5");

_show5.addEventListener('click',()=>{

    document.querySelector(".showmore5").style.display="inline"

    document.querySelector(".show5").style.display="none"

    document.querySelector(".close5").style.display="inline"
})

let _close5= document.querySelector(".close5");

_close5.addEventListener('click',()=>{

    document.querySelector(".showmore5").style.display="none"

    document.querySelector(".show5").style.display="inline"

    document.querySelector(".close5").style.display="none"
})
